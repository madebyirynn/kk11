<?php

include ('config.php');

//sila lengkapkan kod aturacara

header("Location:index.php");

?>




