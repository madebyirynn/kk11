<!--Membuat sambungan ke db-->
<?php

//sila lengkapkan kod aturcara

?>

