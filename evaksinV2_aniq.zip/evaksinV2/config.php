<!--Membuat sambungan ke db-->
<?php

$host = "localhost";
$user = "root";
$pass = "";
$dbname = "evaks";

$conn = mysqli_connect($host, $user, $pass, $dbname);


if(!$conn) {
	echo "not connected";
}
else {
	echo "";
}
?>

//sila lengkapkan kod aturcara



